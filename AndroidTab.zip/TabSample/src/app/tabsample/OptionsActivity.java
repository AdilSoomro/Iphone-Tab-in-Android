package app.tabsample;

import android.app.Activity;
import android.os.Bundle;

/**
 * @author Adil Soomro
 *
 */
public class OptionsActivity extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.optionspage);
        
        
    }
}
