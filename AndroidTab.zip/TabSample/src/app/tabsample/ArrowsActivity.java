package app.tabsample;

import android.app.Activity;
import android.os.Bundle;

/**
 * @author Adil Soomro
 *
 */
public class ArrowsActivity extends Activity {
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.arrowspage);      
    }
}